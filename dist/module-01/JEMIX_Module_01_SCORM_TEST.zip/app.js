var current = 0;
var screens = [];

function showScreen(i) {
  screens.forEach(function(s) { s.classList.remove('active'); });
  screens[i].classList.add('active');
  current = i;
  var progress = Math.round((i / (screens.length - 1)) * 80);
  scormSetProgress(progress, i >= 3 ? 'completed' : 'incomplete');
}

function nextScreen() {
  if (current < screens.length - 1) showScreen(current + 1);
}

function answer(correct) {
  var fb = document.getElementById('feedback');
  if (correct) {
    fb.innerHTML = '<div class="ok">Верно. Насос передает жидкости энергию.</div>';
    scormSetProgress(100, 'completed');
    setTimeout(function() { showScreen(3); }, 800);
  } else {
    fb.innerHTML = '<div class="bad">Неверно. Подумайте, что заставляет воду двигаться.</div>';
    scormSetProgress(50, 'incomplete');
  }
}

window.addEventListener('load', function() {
  screens = Array.prototype.slice.call(document.querySelectorAll('.screen'));
  showScreen(0);
});
