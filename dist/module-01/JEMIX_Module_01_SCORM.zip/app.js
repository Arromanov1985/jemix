var current = -1;
var score = 0;
var answered = {};
var app = document.getElementById('app');

function esc(s) {
  return String(s || '').replace(/[&<>"']/g, function(c) {
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
  });
}

function progressPercent() {
  if (current < 0) return 0;
  return Math.round(((current + 1) / COURSE.screens.length) * 100);
}

function commit(status) {
  var p = progressPercent();
  scormSetProgress(status === 'completed' ? 100 : p, status || (p >= 100 ? 'completed' : 'incomplete'));
}

function startCourse() { current = 0; render(); commit('incomplete'); }
function next() { if (current < COURSE.screens.length - 1) { current++; render(); commit('incomplete'); } else { renderComplete(); } }
function prev() { if (current > 0) { current--; render(); commit('incomplete'); } }

function renderShell(inner) {
  var p = progressPercent();
  app.innerHTML = '<div class="layout">' +
    '<aside class="side"><div class="brand">JEMIX</div><div class="academy">Academy</div><div class="module">' + esc(COURSE.module) + '</div><div class="meter"><span style="width:' + p + '%"></span></div><div class="percent">' + p + '%</div></aside>' +
    '<section class="stage">' + inner + '</section>' +
  '</div>';
}

function renderCover() {
  app.innerHTML = '<section class="cover"><div class="cover-card"><div class="badge">SCORM 1.2</div><h1>JEMIX Academy</h1><h2>Модуль 1. Основы насосной техники</h2><p>Короткие экраны, озвучка, мини-тесты и фиксация прогресса в Бруснике.</p><button onclick="startCourse()">Начать обучение</button></div></section>';
}

function renderLesson(s) {
  var audio = s.audio ? '<div class="audio"><div>Прослушать объяснение</div><audio controls src="' + esc(s.audio) + '"></audio></div>' : '';
  renderShell('<div class="top"><button onclick="prev()">Назад</button><span>' + esc(s.lesson) + ' - ' + esc(s.lessonTitle) + '</span></div><article class="card lesson"><div class="label">Учебный экран</div><h1>' + esc(s.title) + '</h1><p class="lead">' + esc(s.body) + '</p><div class="scheme"><span>Источник</span><b>-</b><span class="pump">Насос</span><b>-</b><span>Потребитель</span></div><div class="note"><strong>Запомните:</strong> ' + esc(s.note) + '</div>' + audio + '<button class="primary" onclick="next()">Далее</button></article>');
}

function renderQuiz(s) {
  var buttons = s.answers.map(function(a, i) { return '<button class="answer" onclick="answer(' + i + ')">' + esc(a.text) + '</button>'; }).join('');
  renderShell('<div class="top"><button onclick="prev()">Назад</button><span>' + esc(s.lesson) + ' - проверка</span></div><article class="card quiz"><div class="label">Мини-тест</div><h1>' + esc(s.question) + '</h1><div class="answers">' + buttons + '</div><div id="feedback"></div></article>');
}

function answer(i) {
  var s = COURSE.screens[current];
  var fb = document.getElementById('feedback');
  if (s.answers[i].correct) {
    if (!answered[current]) { score += 1; answered[current] = true; }
    fb.innerHTML = '<div class="ok">Верно. Можно идти дальше.</div><button class="primary" onclick="next()">Далее</button>';
  } else {
    fb.innerHTML = '<div class="bad">Неверно. Вернитесь к материалу выше и попробуйте еще раз.</div>';
  }
  commit('incomplete');
}

function renderComplete() {
  commit('completed');
  app.innerHTML = '<section class="cover"><div class="cover-card"><div class="badge">Завершено</div><h1>Модуль пройден</h1><h2>JEMIX Academy</h2><p>Результат передан в Бруснику. Можно закрыть урок или перейти к следующему модулю.</p><button onclick="scormFinish()">Завершить</button></div></section>';
}

function render() {
  if (current < 0) return renderCover();
  var s = COURSE.screens[current];
  if (s.type === 'quiz') return renderQuiz(s);
  return renderLesson(s);
}

window.addEventListener('load', renderCover);
