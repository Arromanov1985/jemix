# JEMIX Academy — урок 2.3

Пакет генерирует 20 MP3-файлов через Yandex SpeechKit.

## Запуск в терминале VS Code (PowerShell)

1. Распакуйте архив и перейдите в папку проекта.
2. Создайте `.env`:

```powershell
Copy-Item .\.env.example .\.env
notepad .\.env
```

3. Вставьте ключи:

```text
YANDEX_API_KEY=ваш_ключ
YANDEX_FOLDER_ID=ваш_folder_id
```

4. Запустите:

```powershell
powershell -ExecutionPolicy Bypass -File .un_yandex_audio.ps1
```

Или напрямую:

```powershell
python -m pip install -r .equirements.txt
python .\generate_yandex_audio.py --voice ermil --emotion good --speed 1.0 --overwrite
```

Файлы появятся в папке `audio`: `slide01.mp3` — `slide20.mp3`.
Тексты рассчитаны примерно на 30–40 секунд при скорости 1.0.
