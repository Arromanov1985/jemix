# JEMIX Academy — lesson 2.4 audio

This corrected package generates audio ONLY for lesson 2.4:
"Монтаж, обвязка и типовые схемы подключения".

The narration order matches the current 20-slide archive exactly.
Slides 15 and 17 are intentionally aligned to the actual exported slide order.

## Run in VS Code PowerShell

1. Extract this ZIP into a new empty folder.
2. Open that folder in VS Code.
3. Create `.env`:

```powershell
Copy-Item .\.env.example .\.env
notepad .\.env
```

4. Add credentials:

```text
YANDEX_API_KEY=your_api_key
YANDEX_FOLDER_ID=your_folder_id
```

5. Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_yandex_audio.ps1
```

The runner deletes old `audio\slide*.mp3` files before generation, so audio from lesson 2.2 cannot remain in the folder.
Generated files: `audio\slide01.mp3` ... `audio\slide20.mp3`.
Voice: `ermil`; emotion: `good`; speed: `1.0`.
